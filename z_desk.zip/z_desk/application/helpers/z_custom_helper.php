<?php

defined( 'BASEPATH' ) OR exit( 'No direct script access allowed' );

/**
 * Custom Helper
 *
 * Use this helper to declare your custom functions. The declared
 * functions will be globally accessible. You can also override the
 * script helper functions in it.
 *
 * @author YOUR NAME
 */
